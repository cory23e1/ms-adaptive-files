function myFunction() {

}

// Если страница уже загружена
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', myFunction);
} else {
    myFunction();
}