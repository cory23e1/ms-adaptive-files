const showCards_btn = document.getElementById("showCards_btn");
const refreshData_btn = document.getElementById("refreshData_btn");
const uploadExcel_btn = document.getElementById("uploadExcel");
const uploadTimeExcel_btn = document.getElementById("uploadTimeExcel_btn");
const showRefreshData_btn = document.getElementById("showRefreshData_btn");
const test_btn = document.getElementById("test_btn");

var transData = "";

showCards_btn.addEventListener("click",() => {    
    chrome.tabs.query({active: true}, (tabs) => {
        const tab = tabs[0];
        if (tab) {
            chrome.scripting.executeScript(
                {
                    target:{tabId: tab.id, allFrames: true},
                    func:showCards
                },
            )
        } else {
            alert("There are no active tabs")
        }
    })
})

refreshData_btn.addEventListener("click",() => {    
    chrome.tabs.query({active: true}, (tabs) => {
        const tab = tabs[0];
        if (tab) {
            chrome.scripting.executeScript(
                {
                    target:{tabId: tab.id, allFrames: true},
                    func:refreshData
                },
            )
        } else {
            alert("There are no active tabs")
        }
    })
})

uploadExcel_btn.addEventListener("change",(e) => {    
    const file = e.target.files[0];
    $('#transData_lbl').text(file.name)
    const reader = new FileReader();
    
    reader.onload = function(e) {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, {type: 'array'});
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        transData = jsonData;
        console.log("Data loaded:", jsonData);
        
        // Передаем данные в активную вкладку
        chrome.tabs.query({active: true}, (tabs) => {
            const tab = tabs[0];
            if (tab) {
                chrome.scripting.executeScript({
                    target: {tabId: tab.id, allFrames: true},
                    func: processExcelData,
                    args: [jsonData]
                });
            } else {
                alert("There are no active tabs")
            }
        });
    };
    
    reader.readAsArrayBuffer(file);
})

uploadTimeExcel_btn.addEventListener("change",(e) => {    
    const file = e.target.files[0];
    //$('#transData_lbl').text(file.name)
    const reader = new FileReader();
    
    reader.onload = function(e) {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, {type: 'array'});
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        transData = jsonData;
        console.log("Data loaded:", jsonData);
        
        // Передаем данные в активную вкладку
        chrome.tabs.query({active: true}, (tabs) => {
            const tab = tabs[0];
            if (tab) {
                chrome.scripting.executeScript({
                    target: {tabId: tab.id, allFrames: true},
                    func: processExcelTimeData,
                    args: [jsonData]
                });
            } else {
                alert("There are no active tabs")
            }
        });
    };
    
    reader.readAsArrayBuffer(file);
})

showRefreshData_btn.addEventListener("click",() => {    
    chrome.tabs.query({active: true}, (tabs) => {
        const tab = tabs[0];
        if (tab) {
            chrome.scripting.executeScript(
                {
                    target:{tabId: tab.id, allFrames: true},
                    func:showRefreshData
                },
            )
        } else {
            alert("There are no active tabs")
        }
    })
})

test_btn.addEventListener("click",() => {    
    chrome.tabs.query({active: true}, (tabs) => {
        const tab = tabs[0];
        if (tab) {
            chrome.scripting.executeScript(
                {
                    target:{tabId: tab.id, allFrames: true},
                    func:test
                },
            )
        } else {
            alert("There are no active tabs")
        }
    })
})

function test(){
    // Создаем объект запроса
    const xhr = new XMLHttpRequest();

    // Настраиваем запрос (GET)
    xhr.open('GET', 'https://ektp-app02.rosneft.ru/ektp/servlet/Controller?action=REQUESTTS', true);

    // Устанавливаем обработчики событий
    xhr.onload = function() {
      if (xhr.status >= 200 && xhr.status < 300) {
        const data = JSON.parse(xhr.responseText);
        console.log('Данные получены:', data);
      } else {
        console.error('Ошибка:', xhr.status);
      }
    };

    xhr.onerror = function() {
      console.error('Ошибка сети');
    };

    // Отправляем запрос
    xhr.send();

    // POST-запрос
    const xhrPost = new XMLHttpRequest();
    xhrPost.open('POST', 'https://ektp-app02.rosneft.ru/ektp/servlet/Controller?action=REQUESTTS', true);
    xhrPost.setRequestHeader('Content-Type', 'application/json');

    xhrPost.onload = function() {
      console.log('Ответ:', JSON.parse(xhrPost.responseText));
    };

    xhrPost.send(JSON.stringify({
      title: 'Новый пост',
      body: 'Содержание',
      userId: 1
    }));
}

function showCards() {
    $('.thinlink:contains("Факт. работа")').trigger('click');
    $('.expander-component.toggle-short-long').trigger('click');
}

window.refreshData = function() {
    $('.btn-link:contains("Обновить")').trigger('click');
}

function showRefreshData(){
    $('.thinlink:contains("Факт. работа")').trigger('click');
    $('.expander-component.toggle-short-long').trigger('click');
    $('.btn-link:contains("Обновить")').trigger('click');
}

function changeValues(){
    alert( "Handler for `click` called." );
}

function loadDateTime(){

    function simulateRealClick(number) {
        var $target = $('.clockpicker-tick').filter(function() {
            return $(this).text().trim() === number.toString();
        });
        
        if ($target.length > 0) {
            var element = $target[0];
            var rect = element.getBoundingClientRect();
            
            // Создаем полную последовательность событий
            var events = [
                { type: 'mousedown', clientX: rect.left + rect.width/2, clientY: rect.top + rect.height/2 },
                { type: 'mouseup', clientX: rect.left + rect.width/2, clientY: rect.top + rect.height/2 },
                { type: 'click', clientX: rect.left + rect.width/2, clientY: rect.top + rect.height/2 }
            ];
            
            events.forEach(function(eventData) {
                var event = new MouseEvent(eventData.type, {
                    view: window,
                    bubbles: true,
                    cancelable: true,
                    clientX: eventData.clientX,
                    clientY: eventData.clientY
                });
                element.dispatchEvent(event);
            });
            
            console.log('Полная эмуляция клика для числа ' + number);
            return true;
        }
        return false;
    }

    $('.item-transport-container')
                    .has('span.regNumber a:contains("Х585КА18")')
                    .find('.glyphicon-calendar').first().trigger('click');  //открыть первый datetimepicker

    $('.dtp-popover').find('td:contains("10")').trigger('click');//выбрать число

    let hour = "10";
    let minutes = "30";

    simulateRealClick(hour);
    simulateRealClick(minutes);


    $('.dtp-popover').find('.btn-primary:contains("Применить")').trigger('click');

}

function processExcelTimeData(data){

    function convertExcelDateToJS(excelDate) {
        // Excel даты считаются с 1 января 1900 года
        const excelEpoch = new Date(1900, 0, 1);
        // Вычитаем 2 дня потому что Excel считает 1900 год високосным (ошибка Lotus 1-2-3)
        const jsDate = new Date(excelEpoch.getTime() + (excelDate - 2) * 24 * 60 * 60 * 1000);
        
        // Форматируем в dd.mm.yyyy
        const day = String(jsDate.getDate()).padStart(2, '0');
        const month = String(jsDate.getMonth() + 1).padStart(2, '0');
        const year = jsDate.getFullYear();
        
        return `${day}.${month}.${year}`;
    }

    function parseTimeRange(timeString) {
        // Расширенное регулярное выражение с поддержкой формата ЧЧ:-
        const timeRegex = /^(\d{1,2})(?::(\d{2})?)?-(\d{1,2})(?::(\d{2}))?$/;
        
        const match = timeString.match(timeRegex);
        if (!match) {
            console.error('Неверный формат времени. Ожидается: ЧЧ:ММ-ЧЧ:ММ, ЧЧ-ЧЧ:ММ, ЧЧ-ЧЧ, ЧЧ:ММ-ЧЧ, ЧЧ:-ЧЧ:ММ');
            return null;
        }
        
        // Извлекаем компоненты времени
        const startHours = parseInt(match[1], 10);
        const startMinutes = match[2] !== undefined ? parseInt(match[2] || '0', 10) : 0;
        const endHours = parseInt(match[3], 10);
        const endMinutes = match[4] ? parseInt(match[4], 10) : 0;
        
        // Проверяем валидность времени
        if (startHours < 0 || startHours > 23 || 
            endHours < 0 || endHours > 23 ||
            startMinutes < 0 || startMinutes > 59 ||
            endMinutes < 0 || endMinutes > 59) {
            console.error('Неверное значение времени. Часы должны быть 0-23, минуты 0-59');
            return null;
        }
        
        // Форматируем время с ведущими нулями
        const formatTime = (hours, minutes) => {
            return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
        };
        
        const startTimeStr = formatTime(startHours, startMinutes);
        const endTimeStr = formatTime(endHours, endMinutes);
        const normalizedRange = `${startTimeStr}-${endTimeStr}`;
        
        // Создаем JSON объект
        const timeObject = {
            start: {
                hours: startHours,
                minutes: startMinutes,
                string: startTimeStr
            },
            end: {
                hours: endHours,
                minutes: endMinutes,
                string: endTimeStr
            },
            range: normalizedRange,
            original: timeString
        };
        
        return timeObject;
    }

    function parseDate(dateString) {
        // Проверяем формат даты ДД.ММ.ГГГГ
        const dateRegex = /^(0[1-9]|[12][0-9]|3[01])\.(0[1-9]|1[0-2])\.(\d{4})$/;
        
        if (!dateRegex.test(dateString)) {
            console.error('Неверный формат даты. Ожидается: ДД.ММ.ГГГГ');
            return null;
        }
        
        // Разделяем дату на компоненты
        const [day, month, year] = dateString.split('.').map(Number);
        
        // Создаем объект Date для валидации и получения дополнительной информации
        const date = new Date(year, month - 1, day);
        
        // Проверяем корректность даты (например, 32.13.2025 будет некорректной)
        if (date.getDate() !== day || date.getMonth() !== month - 1 || date.getFullYear() !== year) {
            console.error('Некорректная дата');
            return null;
        }
        
        // Названия дней недели на русском
        const daysOfWeek = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
        
        // Названия месяцев на русском
        const months = [
            'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
            'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'
        ];
        
        // Создаем JSON объект
        const dateObject = {
            original: dateString,
            day: day,
            month: month,
            year: year,
            dayOfWeek: date.getDay(), // 0 - воскресенье, 6 - суббота
            dayOfWeekName: daysOfWeek[date.getDay()],
            monthName: months[month - 1],
            iso: date.toISOString(),
            timestamp: date.getTime(),
            formatted: {
                short: `${day}.${month}.${year}`,
                long: `${day} ${months[month - 1]} ${year} года`,
                withWeekday: `${daysOfWeek[date.getDay()]}, ${day} ${months[month - 1]} ${year} года`
            }
        };
        
        return dateObject;
    }

    console.log(data);

    cardDate = $('.request-tariff-component').first().find('input').val();
    cardContrAgent = $('.commonFields.contractor-container').first().find('span').text().replace(/["']/g, "")
    //cardContrAgent = "ИП Мельников Д.А.";

    console.log("дата карточки", cardDate);
    console.log("Контрагент карточки", cardContrAgent);

    //скрыть карты а то пизда много места занимает
    //$('.expander-component.toggle-short-long').trigger('click');

    carTimeExcelData = [];

    for (let i = 0; i < data.length; i++) {
      dateFromExcel = convertExcelDateToJS(data[i]['Дата']);
      //contrAgentFromExcel = data[i]['Контрагент'];
      if (dateFromExcel == cardDate)
        {
            carTimeExcelData.push(data[i])
        }
    }

    carTimeExcelData.forEach(item => {
        item["Гос. номер"] = item["Гос. номер"].replace(/[\/.\s]/g, '');
    });

    console.log(carTimeExcelData);

    carCards = $('.request-extension-container.mounting');

    let carObjects = []
    let regNumbersEKTP = []

        // Функция для задержки
    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Основная функция с задержками
    async function processCarCards() {
        for (let i = 0; i < carCards.length; i++) {
            try {
                regNumberEKTP = $(carCards[i]).find('.regNumber').find('a').text();
                console.log("ИЗ ЕКТП: "+regNumberEKTP);
                regNumbersEKTP.push(regNumberEKTP);

                carObject = carTimeExcelData.find(item => item["Гос. номер"] === regNumberEKTP);
                
                if (!carObject) {
                    console.warn(`Не найден объект для гос. номера: ${regNumberEKTP}`);
                    continue;
                }
                
                let workTime = carObject['Время работы, ч'];
                console.log(workTime);

                let startHour = parseTimeRange(workTime).start.hours;
                console.log("Начало ч.: "+startHour);
                let startMinutes = parseTimeRange(workTime).start.minutes;
                console.log("Начало мин.: "+startMinutes);

                let endHour = parseTimeRange(workTime).end.hours;
                console.log("Конец ч.: "+endHour);
                let endMinutes = parseTimeRange(workTime).end.minutes;
                console.log("Конец мин.: "+endMinutes);

                let day = parseDate(cardDate).day;
                console.log(day);

                function simulateRealClick(number) {
                    var $target = $('.clockpicker-tick').filter(function() {
                        return $(this).text().trim() === number.toString();
                    });
                    
                    if ($target.length > 0) {
                        var element = $target[0];
                        var rect = element.getBoundingClientRect();
                        
                        // Создаем полную последовательность событий
                        var events = [
                            { type: 'mousedown', clientX: rect.left + rect.width/2, clientY: rect.top + rect.height/2 },
                            { type: 'mouseup', clientX: rect.left + rect.width/2, clientY: rect.top + rect.height/2 },
                            { type: 'click', clientX: rect.left + rect.width/2, clientY: rect.top + rect.height/2 }
                        ];
                        
                        events.forEach(function(eventData) {
                            var event = new MouseEvent(eventData.type, {
                                view: window,
                                bubbles: true,
                                cancelable: true,
                                clientX: eventData.clientX,
                                clientY: eventData.clientY
                            });
                            element.dispatchEvent(event);
                        });
                        
                        console.log('Полная эмуляция клика для числа ' + number);
                        return true;
                    }
                    return false;
                }

                let transportContainer = $('.item-transport-container')
                    .has('span.regNumber a:contains("'+regNumberEKTP+'")')
                    .find('.glyphicon-calendar');

                for (let j = 0; j < 2; j++) {
                    $(transportContainer[j]).trigger("click");

                    // Ждем появления datepicker
                    await delay(300);

                    // Выбираем число с проверкой
                    let dayElement = null;
                    let attempts = 0;
                    while (attempts < 5) {
                        // dayElement = $('.dtp-popover').find('td').filter(function() {
                        //     return $(this).text().trim() === day.toString();
                        // });
                        dayElement = $('.dtp-popover').find('td').filter(function() {
                            return $(this).text().trim() === day.toString() && !$(this).hasClass('old');
                        });
                        
                        if (dayElement.length > 0) {
                            dayElement.trigger('click');
                            console.log('День ' + day + ' выбран');
                            break;
                        }
                        await delay(200);
                        attempts++;
                    }

                    if (!dayElement || dayElement.length === 0) {
                        console.warn('Не удалось найти день ' + day + ', пропускаем карточку');
                        continue;
                    }

                    // Ждем появления timepicker
                    await delay(300);

                    let hour = "";
                    let minutes = "";

                    if (j==1){
                        hour = endHour;
                        minutes = endMinutes;
                    }
                    else{
                        hour = startHour;
                        minutes = startMinutes;
                    }

                    // Кликаем час с проверкой
                    let hourClicked = false;
                    attempts = 0;
                    while (attempts < 5 && !hourClicked) {
                        hourClicked = simulateRealClick(hour);
                        if (!hourClicked) {
                            await delay(200);
                            attempts++;
                        }
                    }

                    // Ждем перед выбором минут
                    await delay(300);

                    // Кликаем минуты с проверкой
                    let minutesClicked = false;
                    attempts = 0;
                    while (attempts < 5 && !minutesClicked) {
                        minutesClicked = simulateRealClick(minutes);
                        if (!minutesClicked) {
                            await delay(200);
                            attempts++;
                        }
                    }

                    // Ждем перед применением
                    await delay(300);

                    // Применяем изменения
                    $('.dtp-popover').find('.btn-primary:contains("Применить")').trigger('click');

                    // Ждем перед следующей карточкой
                    await delay(300);
                    }

            } catch (error) {
                console.log(`Общая ошибка при обработке карточки ${i}:`, error.message);
                continue;
            }
        }
        //refreshData();
        $('.btn-link:contains("Обновить")').trigger('click');
    }

    // Запускаем обработку
    processCarCards();
}

//функция для обработки данных Excel на странице
function processExcelData(data) {

    function convertExcelDateToJS(excelDate) {
        // Excel даты считаются с 1 января 1900 года
        const excelEpoch = new Date(1900, 0, 1);
        // Вычитаем 2 дня потому что Excel считает 1900 год високосным (ошибка Lotus 1-2-3)
        const jsDate = new Date(excelEpoch.getTime() + (excelDate - 2) * 24 * 60 * 60 * 1000);
        
        // Форматируем в dd.mm.yyyy
        const day = String(jsDate.getDate()).padStart(2, '0');
        const month = String(jsDate.getMonth() + 1).padStart(2, '0');
        const year = jsDate.getFullYear();
        
        return `${day}.${month}.${year}`;
    }

    function simulateKeyboardInput(inputElement, text) {
        if (!inputElement) return;
        
        // Фокусируемся на инпуте
        inputElement.focus();
        
        // Очищаем текущее значение
        inputElement.value = '';
        $(inputElement).trigger('focus').trigger('select');
        
        // Имитируем ввод каждого символа
        for (let i = 0; i < text.length; i++) {
            setTimeout(() => {
                const char = text[i];
                
                // Создаем события для каждого символа
                const keydownEvent = new KeyboardEvent('keydown', {
                    key: char,
                    code: `Key${char.toUpperCase()}`,
                    keyCode: char.charCodeAt(0),
                    which: char.charCodeAt(0),
                    bubbles: true,
                    cancelable: true
                });
                
                const keypressEvent = new KeyboardEvent('keypress', {
                    key: char,
                    code: `Key${char.toUpperCase()}`,
                    keyCode: char.charCodeAt(0),
                    which: char.charCodeAt(0),
                    bubbles: true,
                    cancelable: true
                });
                
                const inputEvent = new InputEvent('input', {
                    inputType: 'insertText',
                    data: char,
                    bubbles: true,
                    cancelable: true
                });
                
                const keyupEvent = new KeyboardEvent('keyup', {
                    key: char,
                    code: `Key${char.toUpperCase()}`,
                    keyCode: char.charCodeAt(0),
                    which: char.charCodeAt(0),
                    bubbles: true,
                    cancelable: true
                });
                
                // Диспатчим события
                inputElement.dispatchEvent(keydownEvent);
                inputElement.dispatchEvent(keypressEvent);
                
                // Добавляем символ к значению
                inputElement.value += char;
                $(inputElement).val(inputElement.value);
                
                inputElement.dispatchEvent(inputEvent);
                inputElement.dispatchEvent(keyupEvent);
                
            }, i * 50); // Задержка между символами (50ms)
        }
        
        // Финальные события после ввода всего текста
        setTimeout(() => {
            inputElement.dispatchEvent(new Event('change', { bubbles: true }));
            inputElement.dispatchEvent(new Event('blur', { bubbles: true }));
        }, text.length * 50 + 100);
    }

    function simulateRealisticInput(inputElement, text) {
        if (!inputElement) return;
        
        return new Promise((resolve) => {
            // Фокусируемся на инпуте
            inputElement.focus();
            inputElement.select();
            
            // Очищаем значение с событиями
            inputElement.value = '';
            $(inputElement).val('');
            
            // Событие очистки
            inputElement.dispatchEvent(new Event('input', { bubbles: true }));
            inputElement.dispatchEvent(new Event('change', { bubbles: true }));
            
            let currentText = '';
            
            // Функция для ввода следующего символа
            function typeNextChar(index) {
                if (index >= text.length) {
                    // Завершаем ввод
                    inputElement.dispatchEvent(new Event('change', { bubbles: true }));
                    inputElement.dispatchEvent(new KeyboardEvent('keyup', {
                        key: 'Enter',
                        code: 'Enter',
                        keyCode: 13,
                        which: 13,
                        bubbles: true
                    }));
                    inputElement.blur();
                    resolve();
                    return;
                }
                
                const char = text[index];
                currentText += char;
                
                // Создаем реалистичные события
                const keyDownEvent = new KeyboardEvent('keydown', {
                    key: char,
                    code: `Key${char.toUpperCase()}`,
                    keyCode: char.charCodeAt(0),
                    which: char.charCodeAt(0),
                    bubbles: true
                });
                
                const inputEvent = new InputEvent('input', {
                    inputType: 'insertText',
                    data: char,
                    bubbles: true,
                    dataTransfer: null,
                    isComposing: false
                });
                
                const keyUpEvent = new KeyboardEvent('keyup', {
                    key: char,
                    code: `Key${char.toUpperCase()}`,
                    keyCode: char.charCodeAt(0),
                    which: char.charCodeAt(0),
                    bubbles: true
                });
                
                // Диспатчим события
                inputElement.dispatchEvent(keyDownEvent);
                inputElement.value = currentText;
                $(inputElement).val(currentText);
                inputElement.dispatchEvent(inputEvent);
                inputElement.dispatchEvent(keyUpEvent);
                
                // Следующий символ с случайной задержкой (как у человека)
                const delay = 50 + Math.random() * 100; // 50-150ms
                setTimeout(() => typeNextChar(index + 1), delay);
            }
            
            // Начинаем ввод
            setTimeout(() => typeNextChar(0), 100);
        });
    }


    // Функция для имитации ввода в конкретный инпут
    async function setInputWithKeyboard(selector, value) {
        try {
            const inputElement = $(selector)[0];
            if (inputElement) {
                console.log(`Имитируем ввод "${value}" в инпут`);
                await simulateRealisticInput(inputElement, value.toString());
            }
        } catch (error) {
            console.log('Ошибка при имитации ввода:', error);
        }
    }

    //поиск карточек по дате и контрагенту в Excel

    cardDate = $('.request-tariff-component').first().find('input').val();
    cardContrAgent = $('.commonFields.contractor-container').first().find('span').text().replace(/["']/g, "")
    //cardContrAgent = "ИП Мельников Д.А.";

    console.log("дата карточки", cardDate);
    console.log("Контрагент карточки", cardContrAgent);

    //скрыть карты а то пизда много места занимает
    $('.expander-component.toggle-short-long').trigger('click');

    carExcelData = []

    for (let i = 0; i < data.length; i++) {
      dateFromExcel = convertExcelDateToJS(data[i]['Дата']);
      contrAgentFromExcel = data[i]['Контрагент'];
      if (dateFromExcel == cardDate && contrAgentFromExcel == cardContrAgent)
        {
            carExcelData.push(data[i])
        }
    }

    carExcelData.forEach(item => {
        item["Гос. номер"] = item["Гос. номер"].replace(/[\/.\s]/g, '');
    });

    //поиск карточек по дате и контрагенту в Excel

    carCards = $('.request-extension-container.mounting');

    //получение объектов с данными по нужным машинам

    let carObjects = []
    let regNumbersEKTP = []

    for (let i = 0; i < carCards.length; i++) {
        try {
            regNumberEKTP = $(carCards[i]).find('.regNumber').find('a').text();
            console.log("ИЗ ЕКТП: "+regNumberEKTP);
            regNumbersEKTP.push(regNumberEKTP);

            // Находим ВСЕ объекты с одинаковым гос. номером
            const carObjectsWithSameNumber = carExcelData.filter(item => item["Гос. номер"] === regNumberEKTP);
            
            if (!carObjectsWithSameNumber || carObjectsWithSameNumber.length === 0) {
                console.warn(`Не найден объект для гос. номера: ${regNumberEKTP}`);
                continue;
            }
            
            // Суммируем значения из всех найденных объектов
            let totalWorkTime = 0;
            let totalKm = 0;
            
            carObjectsWithSameNumber.forEach(carObj => {
                totalWorkTime += parseFloat(carObj['Время работы, ч']) || 0;
                totalKm += parseFloat(carObj['Пройденое расстояние, км']) || 0;
            });
            
            console.log(`Для ${regNumberEKTP} найдено ${carObjectsWithSameNumber.length} записей: время=${totalWorkTime}, пробег=${totalKm}`);
            
            let formatedWorkTime = totalWorkTime.toString().replace('.',',');
            
            // Сохраняем первый объект для других данных (если нужно)
            carObject = carObjectsWithSameNumber[0];
            carObjects.push(carObject);

            // Устанавливаем пробег с имитацией клавиатуры
            try {
                var kmInputSelector = $('.item-transport-container')
                    .has('span.regNumber a:contains("'+regNumberEKTP+'")')
                    .find('label.control-label:contains("Пробег, км")')
                    .parent()
                    .find('input.typeGlonassDisabled');

                setInputWithKeyboard(kmInputSelector, totalKm);
                kmInputSelector.data('km', totalKm);
            } catch (error) {
                console.log(`Ошибка при установке пробега для ${regNumberEKTP}:`, error.message);
            }

            // Устанавливаем время работы с имитацией клавиатуры
            try {
                var timeInputSelector = $('.item-transport-container')
                    .has('span.regNumber a:contains("'+regNumberEKTP+'")')
                    .find('label.control-label:contains("Машиночасы, ч")')
                    .parent()
                    .find('input.typeGlonassDisabled');

                setInputWithKeyboard(timeInputSelector, formatedWorkTime);
                timeInputSelector.data('time', formatedWorkTime);
            } catch (error) {
                console.log(`Ошибка при установке времени работы для ${regNumberEKTP}:`, error.message);
            }
            
        } catch (error) {
            console.log(`Общая ошибка при обработке карточки ${i}:`, error.message);
            continue;
        }
    }

    console.log(carObjects);

    let transDataPanel = $('.item-transport-container').has('span.regNumber').find('label.control-label:contains("Машиночасы, ч")').parent().parent();
    if (transDataPanel.find('#change_values').length === 0) {
        $('.item-transport-container').has('span.regNumber').find('label.control-label:contains("Машиночасы, ч")').parent().parent().append("<button style='height: 30px;margin-top: 20px;' id='change_values'>Поменять</button>");
    }
    if (transDataPanel.find('#put_zero').length === 0) {
        $('.item-transport-container').has('span.regNumber').find('label.control-label:contains("Машиночасы, ч")').parent().parent().append("<button style='height: 30px;margin-top: 20px;' id='put_zero'>0 км 0 ч.</button>");
    }

    $(document).on('click', '#change_values', function() {
        let timeWork = $(this).parent().find('label.control-label:contains("Машиночасы, ч")').parent().find('input.typeGlonassDisabled').data('time');
        let km = $(this).parent().find('label.control-label:contains("Пробег, км")').parent().find('input.typeGlonassDisabled').data('km');

        //поменять местами время и километры
        let kmInput = $(this).parent().find('label.control-label:contains("Машиночасы, ч")').parent().find('input.typeGlonassDisabled');
        setInputWithKeyboard(kmInput, km);
        kmInput.data('km', km);

        let timeWorkInput = $(this).parent().find('label.control-label:contains("Пробег, км")').parent().find('input.typeGlonassDisabled');
        setInputWithKeyboard(timeWorkInput, timeWork);
        timeWorkInput.data('time', timeWork);
    });

    $(document).on('click', '#put_zero', function() {
        let kmInput = $(this).parent().find('label.control-label:contains("Пробег, км")').parent().find('input.typeGlonassDisabled');
        setInputWithKeyboard(kmInput, '0');

        let timeWorkInput = $(this).parent().find('label.control-label:contains("Машиночасы, ч")').parent().find('input.typeGlonassDisabled');
        setInputWithKeyboard(timeWorkInput, '0');
    });


    //получение объектов с данными по нужным машинам
    
    console.log(carExcelData);
    //console.log(convertExcelDateToJS(data[0]['Дата']));
}