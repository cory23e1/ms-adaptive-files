from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import QtCore, QtGui, QtWidgets, QtSql
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment
from win32com.client import Dispatch


import main_form
import openpyxl
import os
import sys
from transformator import Transformator
from substation import Substation
import re
from HARG import HARG
from SQL import SQL

class Main(main_form.Ui_MainWindow,QMainWindow):
    gases = ["H2", "CH4", "C2H4", "C2H2", "C2H6", "CO2", "CO"]
    selected_trans_id = ""
    # здесь можно определить какие нибудь переменные, костянки

    def __init__(self,parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setWindowFlags(QtCore.Qt.Window)
        self.setupUi(self)

        self.sel_trans_btn.clicked.connect(self.open_trans_win)
        self.anal_btn.clicked.connect(self.do_anal)
        self.add_trans_act.triggered.connect(self.open_trans_win)
        self.add_subs_act.triggered.connect(self.open_subs_win)
        self.trans_up_btn.clicked.connect(lambda:self.switch_trans(switch="up"))
        self.trans_down_btn.clicked.connect(lambda: self.switch_trans(switch="down"))

        self.construct_trans_data_tbl()
        self.trans = Transformator(self)
        self.sql = SQL()

        # СЮДА МОЖНО НАЕБЕНИТЬ КАКИЕ НИБУДЬ ФУНКЦИИ КОТОРЫЕ БУДУТ ВЫЗЫВАТЬСЯ ПРИ СТАРТЕ

    def load_trans(self,trans_id):
        trans_data = self.sql.get_data("SELECT "+
                       "transformators.name,"+
                       "transformators.factory_n,"+
                       "substations.name AS substation,"+
                       "transformators.image AS image,"+
                       "trans_protect.name AS protect,"+
                       "transformators.date_create AS date_create,"+
                       "transformators.date_start AS date_start "+
                       "FROM transformators " +
                       "INNER JOIN substations ON transformators.substation=substations.id " +
                       "INNER JOIN trans_protect ON transformators.protect=trans_protect.id " +
                       "WHERE transformators.id="+trans_id
                     ,"dict")

        substation = trans_data.get('substation')
        factory_n = trans_data.get('factory_n')
        name = trans_data.get('name')
        image = trans_data.get('image')
        protect = trans_data.get('protect')
        date_create = trans_data.get('date_create')
        date_start = trans_data.get('date_start')

        self.trans_ps_lbl.setText((str)(substation))
        self.trans_number_lbl.setText((str)(factory_n))
        self.trans_model_lbl.setText((str)(name))
        self.trans_protect_lbl.setText(str(protect))
        self.trans_date_create_lbl.setText(str(date_create))
        self.trans_date_create_lbl_2.setText(str(date_start))

        pixmap = QPixmap((str)(image))
        self.trans_img.setPixmap(pixmap)

        self.load_trans_gas_data()

    def switch_trans(self, switch=""):
        #загрузка всех имеющихся айдишников трансформаторов
        raw_trans_ids = self.sql.get_data("SELECT id FROM transformators",type="default")

        trans_ids = ()
        for raw_id in raw_trans_ids:
            id = re.sub(r'[^\w\s]', '', str(raw_id))
            trans_ids += (id,)

        # листание транфсорматоров по айдишникам
        if self.selected_trans_id != "":
            index = trans_ids.index(self.selected_trans_id)
            index_count = len(trans_ids)

            if switch=="up":
                self.selected_trans_id = trans_ids[index - 1]

            elif switch=="down":
                if not (index>=index_count-1):
                    self.selected_trans_id = trans_ids[index + 1]
                else:
                    self.selected_trans_id = trans_ids[0]

            self.load_trans(self.selected_trans_id)

            #ЗАГРУЗКА ХАРГА по ИД
            self.load_HARG()


        elif self.selected_trans_id == "":
            self.selected_trans_id = trans_ids[0]
            self.load_trans(self.selected_trans_id)

            # ЗАГРУЗКА ХАРГА по ИД
            self.load_HARG()

    def construct_trans_data_tbl(self):

        model = QStandardItemModel()
        model.setHorizontalHeaderLabels(["Газ", "Концентрация"])

        for gas in self.gases:
            new_row = []
            new_row.append(QStandardItem(gas))
            model.appendRow(new_row)

        self.gas_input_tbl.setModel(model)

        for i in range(len(self.gases)):
            self.gas_input_tbl.setIndexWidget(model.index(i, 1), QDoubleSpinBox())
            self.gas_input_tbl.indexWidget(self.gas_input_tbl.model().index(i, 1)).setDecimals(4)
            #self.gas_input_tbl.indexWidget(self.gas_input_tbl.model().index(i, 1)).setSingleStep(0.0001)

        #self.gas_input_tbl.setEditTriggers(QAbstractItemView.AllEditTriggers) # Если нужно разрешить редактирование

    def load_trans_gas_data(self):
        raw_concetrations = self.sql.get_data('SELECT otbor.date AS "Дата", otbor.h2 AS "H2", ch4 AS "CH4", c2h4 AS "C2H4", c2h2 AS "C2H2", c2h6 AS "C2H6", co2 AS "CO2", co AS "CO" FROM otbor WHERE transformator = '+self.selected_trans_id,type="default")

        if(raw_concetrations!=[]):
            model = QStandardItemModel()
            model.setVerticalHeaderLabels(self.gases)

            date_columns = []

            for i in range(len(raw_concetrations)):
                date_columns.append(raw_concetrations[i][0])
                model.setHorizontalHeaderLabels(date_columns)

                for j in range(len(raw_concetrations[i])):
                    #print(raw_concetrations[i][j])
                    model.setItem(j-1, i, QtGui.QStandardItem(raw_concetrations[i][j]))

            self.trans_gas_data_tbl.setModel(model)
        else:
            model = QStandardItemModel()
            self.trans_gas_data_tbl.setModel(model)
            return []

    def collect_gas_conc(self):
        raw_data_gases = {}

        # СБОР КОНЦЕНТРАЦИй ГАЗОВ

        for i in range(len(self.gases)):
            gas = self.gas_input_tbl.model().index(i, 0).data()
            raw_concentration = self.gas_input_tbl.indexWidget(self.gas_input_tbl.model().index(i, 1)).value()
            concentration = str(raw_concentration).replace(".", ",")
            raw_data_gases[gas] = concentration

        print(raw_data_gases)

        check_gas_fields = all(gas == '0,0' for gas in raw_data_gases.values())

        print(check_gas_fields)

        if check_gas_fields == True:
            return False
        else:
            return raw_data_gases

    def clear_gas_conc_fields(self):
        # ОЧИСТКА СПИНБОКСОВ ДЛЯ ВВОДА КОНЦЕНТРАЦИЙ
        for i in range(len(self.gases)):
            self.gas_input_tbl.indexWidget(self.gas_input_tbl.model().index(i, 1)).setValue(0.0)

    def add_gas_conc_to_db(self):
        # ДОБАВЛЕНИЕ КОНЦЕНТРАЦИЙ ГАЗОВ ПО ДАТЕ В БД
        data_gases = self.collect_gas_conc()

        if data_gases == False:
            self.show_msg('Концентрации газов не заполнены!')
        else:
            H2 = data_gases["H2"]
            CH4 = data_gases["CH4"]
            C2H4 = data_gases["C2H4"]
            C2H2 = data_gases["C2H2"]
            C2H6 = data_gases["C2H6"]
            CO2 = data_gases["CO2"]
            CO = data_gases["CO"]

            transformator = self.selected_trans_id
            date = self.trans_date_conc_input.text()

            data = (transformator, date, H2, CH4, C2H4, C2H2, C2H6, CO2, CO)

            self.sql.insert_data('INSERT INTO otbor (transformator, date, h2, ch4, c2h4, c2h2, c2h6, co2, co) VALUES (?,?,?,?,?,?,?,?,?)',data)

            #ОЧИСТКА ПОЛЕЙ КОНЦЕНТРАЦИЙ ГАЗОВ
            self.clear_gas_conc_fields()

    def do_anal(self):

        if self.selected_trans_id!="":
            #ОБНОВЛЕНИЕ ТАБЛИЦЫ КОНЦЕНТРАЦИЙ ГАЗОВ

            trans_gas_data = self.load_trans_gas_data()

            if(trans_gas_data == []):
                self.show_msg('Данные концентраций газов отсутствуют!')
                # ДОБАВЛЕНИЕ НОВОЙ ЗАПИСИ В БД
                self.add_gas_conc_to_db()
                self.load_trans_gas_data()
            else:
                #АНАЛИЗ КОНЦЕНТРАЦИЙ
                data_gases = self.collect_gas_conc()

                H2 = data_gases["H2"]
                CH4 = data_gases["CH4"]
                C2H4 = data_gases["C2H4"]
                C2H2 = data_gases["C2H2"]
                C2H6 = data_gases["C2H6"]
                CO2 = data_gases["CO2"]
                CO = data_gases["CO"]
                date = self.trans_date_conc_input.text()

                harg = HARG(self.selected_trans_id, H2,CH4,C2H4,C2H2,C2H6,CO2,CO,date)
                result = harg.do_HARG()
                self.report_output(result)

                #ДОБАВЛЕНИЕ НОВОЙ ЗАПИСИ В БД
                self.add_gas_conc_to_db()

                #ЗАГРУЗКА ДАННЫХ ГАЗОВ ПО ТРАНСФОРМАТОРУ ИЗ БД
                self.load_trans_gas_data()

                # ОЧИСТКА ПОЛЕЙ КОНЦЕНТРАЦИЙ ГАЗОВ
                self.clear_gas_conc_fields()

                self.load_HARG()

                self.excel_report()
        else:
            self.show_msg('Выберите трансформатор')

    def load_HARG(self):
        harg = HARG(trans_id = self.selected_trans_id)
        HARG_data = harg.sel_last_HARG()

        if HARG_data != None:
            self.HARG_last_date_lbl.setText(HARG_data.get("date"))
            self.previshenie_granic_lbl.setText(HARG_data.get("previshenie_granich_concentraciy"))

            self.H2_lbl.setText(str(HARG_data.get("h2")))
            self.CH4_lbl.setText(str(HARG_data.get("ch4")))
            self.C2H4_lbl.setText(str(HARG_data.get("c2h4")))
            self.C2H2_lbl.setText(str(HARG_data.get("c2h2")))
            self.C2H6_lbl.setText(str(HARG_data.get("c2h6")))
            self.CO2_lbl.setText(str(HARG_data.get("co2")))
            self.CO_lbl.setText(str(HARG_data.get("co")))

            self.C2H2_C2H4_lbl.setText(str(round(HARG_data.get("c2h2_c2h4"),5)))
            self.CH4_H2_lbl.setText(str(round(HARG_data.get("ch4_h2"),5)))

            self.C2H4_C2H6_lbl.setText(str(round(HARG_data.get("c2h4_c2h6"),5)))
            self.CO2_CO_lbl.setText(str(round(HARG_data.get("co2_co"),5)))

            self.H2_absolut_speed_lbl.setText(str(HARG_data.get("h2_absolut_speed")))
            self.CH4_absolut_speed_lbl.setText(str(HARG_data.get("ch4_absolut_speed")))
            self.C2H4_absolut_speed_lbl.setText(str(HARG_data.get("c2h4_absolut_speed")))
            self.C2H2_absolut_speed_lbl.setText(str(HARG_data.get("c2h2_absolut_speed")))
            self.C2H6_absolut_speed_lbl.setText(str(HARG_data.get("c2h6_absolut_speed")))
            self.CO2_absolut_speed_lbl.setText(str(HARG_data.get("co2_absolut_speed")))
            self.CO_absolut_speed_lbl.setText(str(HARG_data.get("co_absolut_speed")))

            self.H2_otnos_speed_lbl.setText(str(round(HARG_data.get("h2_otnos_speed"),5)))
            self.CH4_otnos_speed_lbl.setText(str(round(HARG_data.get("ch4_otnos_speed"),5)))
            self.C2H4_otnos_speed_lbl.setText(str(round(HARG_data.get("c2h4_otnos_speed"),5)))
            self.C2H2_otnos_speed_lbl.setText(str(round(HARG_data.get("c2h2_otnos_speed"),5)))
            self.C2H6_otnos_speed_lbl.setText(str(round(HARG_data.get("c2h6_otnos_speed"),5)))
            self.CO2_otnos_speed_lbl.setText(str(round(HARG_data.get("co2_otnos_speed"),5)))
            self.CO_otnos_speed_lbl.setText(str(round(HARG_data.get("co_otnos_speed"),5)))

            self.defekt_4_gaza_peregrev_razryad_lbl.setText(str(HARG_data.get("peregrev_razryad_4_gaza")))
            self.defekt_4_gaza_peregrev_CO_lbl.setText(str(HARG_data.get("defekt_4_gaza_peregrev_CO")))
            self.defekt_5_gazov_lbl.setText(str(HARG_data.get("defekt_5_gazov")))
            self.defekt_5_gazov_maslo_izolyacia_lbl.setText(str(HARG_data.get("defekt_maslo_izolyacia_5_gazov")))
        else:
            self.HARG_last_date_lbl.setText("-")
            self.previshenie_granic_lbl.setText("-")

            self.H2_lbl.setText("0,0")
            self.CH4_lbl.setText("0,0")
            self.C2H4_lbl.setText("0,0")
            self.C2H2_lbl.setText("0,0")
            self.C2H6_lbl.setText("0,0")
            self.CO2_lbl.setText("0,0")
            self.CO_lbl.setText("0,0")

            self.C2H2_C2H4_lbl.setText("0,0")
            self.CH4_H2_lbl.setText("0,0")

            self.C2H4_C2H6_lbl.setText("0,0")
            self.CO2_CO_lbl.setText("0,0")

            self.H2_absolut_speed_lbl.setText("-")
            self.CH4_absolut_speed_lbl.setText("-")
            self.C2H4_absolut_speed_lbl.setText("-")
            self.C2H2_absolut_speed_lbl.setText("-")
            self.C2H6_absolut_speed_lbl.setText("-")
            self.CO2_absolut_speed_lbl.setText("-")
            self.CO_absolut_speed_lbl.setText("-")

            self.H2_otnos_speed_lbl.setText("-")
            self.CH4_otnos_speed_lbl.setText("-")
            self.C2H4_otnos_speed_lbl.setText("-")
            self.C2H2_otnos_speed_lbl.setText("-")
            self.C2H6_otnos_speed_lbl.setText("-")
            self.CO2_otnos_speed_lbl.setText("-")
            self.CO_otnos_speed_lbl.setText("-")

            self.defekt_4_gaza_peregrev_razryad_lbl.setText("-")
            self.defekt_4_gaza_peregrev_CO_lbl.setText("-")
            self.defekt_5_gazov_lbl.setText("-")
            self.defekt_5_gazov_maslo_izolyacia_lbl.setText("-")

        HARG_data_all = harg.sel_all_HARG()
        self.hargs_data_tbl.setModel(HARG_data_all)

        print(HARG_data_all)

    def excel_report(self):

        harg = HARG(trans_id = self.selected_trans_id)
        HARG_data = harg.sel_last_HARG()

        trans_info = self.sql.get_data(
            'SELECT transformators.id AS id,' +
            'transformators.name AS name,' +
            'transformators.factory_n AS factory_n,' +
            'substations.name AS substation,' +
            'trans_protect.name AS trans_protect,' +
            'transformators.date_create AS date_create,' +
            'transformators.date_start AS date_start ' +
            'FROM transformators ' +
            'INNER JOIN substations ON transformators.substation=substations.id ' +
            'INNER JOIN trans_protect ON transformators.protect=trans_protect.id ' +
            'WHERE transformators.id = ' + self.selected_trans_id
        ,type="dict")

        print(trans_info)

        wb = Workbook()
        # Активируем текущий лист
        ws = wb.active
        wrap_text = Alignment(wrap_text=True)
        # Заполняем ячейки данными
        ws['D1'] = "Отчет о состоянии трансформаторного масла"

        ws['A3'] = "Объект:"+str(trans_info.get('substation'))+" "+str(trans_info.get('name'))+ " Зав.№ "+ str(trans_info.get('factory_n'))

        ws['A4'] = "Дата отбора"
        ws['A4'].alignment = wrap_text

        ws['B4'] = "Дата анализа"
        ws['B4'].alignment = wrap_text
        ws['B5'] = str(HARG_data.get("date"))

        ws['C4'] = "Температура масла при отборе (С)"
        ws['C4'].alignment = wrap_text
        ws['D4'] = "Нагрузка при отборе (%)"
        ws['D4'].alignment = wrap_text

        ws['A7'] = "1.Граничные концентрации растворенных в масле газов"

        ws['A8'] = "H2 водород"
        ws['A8'].alignment = wrap_text
        ws['A9'] = str(HARG_data.get("h2"))
        ws['A9'].alignment = wrap_text

        ws['B8'] = "CH4 метан"
        ws['B8'].alignment = wrap_text
        ws['B9'] = str(HARG_data.get("ch4"))
        ws['B9'].alignment = wrap_text

        ws['C8'] = "C2H4 этилен"
        ws['C8'].alignment = wrap_text
        ws['C9'] = str(HARG_data.get("c2h4"))
        ws['C9'].alignment = wrap_text

        ws['D8'] = "C2H2 ацетилен"
        ws['D8'].alignment = wrap_text
        ws['D9'] = str(HARG_data.get("c2h2"))
        ws['D9'].alignment = wrap_text

        ws['E8'] = "C2H6 этан"
        ws['E8'].alignment = wrap_text
        ws['E9'] = str(HARG_data.get("c2h6"))
        ws['E9'].alignment = wrap_text

        ws['F8'] = "CO2 угл.газ"
        ws['F8'].alignment = wrap_text
        ws['F9'] = str(HARG_data.get("co2"))
        ws['F9'].alignment = wrap_text

        ws['G8'] = "CO оксид углерода"
        ws['G8'].alignment = wrap_text
        ws['G9'] = str(HARG_data.get("co"))
        ws['G9'].alignment = wrap_text

        ws['A11'] = "2.Результаты измерений"

        ws['A12'] = "H2 водород"
        ws['A12'].alignment = wrap_text
        ws['B12'] = "CH4 метан"
        ws['B12'].alignment = wrap_text
        ws['C12'] = "C2H4 этилен"
        ws['C12'].alignment = wrap_text
        ws['D12'] = "C2H2 ацетилен"
        ws['D12'].alignment = wrap_text
        ws['E12'] = "C2H6 этан"
        ws['E12'].alignment = wrap_text
        ws['F12'] = "CO2 угл.газ"
        ws['F12'].alignment = wrap_text
        ws['G12'] = "CO оксид углерода"
        ws['G12'].alignment = wrap_text

        ws['A15'] = "3.Скорость нарастания концентрации газов (%)"

        ws['A16'] = "H2 водород"
        ws['A16'].alignment = wrap_text
        ws['A17'] = str(HARG_data.get("h2_otnos_speed"))
        ws['A17'].alignment = wrap_text

        ws['B16'] = "CH4 метан"
        ws['B16'].alignment = wrap_text
        ws['B17'] = str(HARG_data.get("ch4_otnos_speed"))
        ws['B17'].alignment = wrap_text

        ws['C16'] = "C2H4 этилен"
        ws['C16'].alignment = wrap_text
        ws['C17'] = str(HARG_data.get("c2h4_otnos_speed"))
        ws['C17'].alignment = wrap_text

        ws['D16'] = "C2H2 ацетилен"
        ws['D16'].alignment = wrap_text
        ws['D17'] = str(HARG_data.get("c2h2_otnos_speed"))
        ws['D17'].alignment = wrap_text

        ws['E16'] = "C2H6 этан"
        ws['E16'].alignment = wrap_text
        ws['E17'] = str(HARG_data.get("c2h6_otnos_speed"))
        ws['E17'].alignment = wrap_text

        ws['F16'] = "CO2 угл.газ"
        ws['F16'].alignment = wrap_text
        ws['F17'] = str(HARG_data.get("co2_otnos_speed"))
        ws['F17'].alignment = wrap_text

        ws['G16'] = "CO оксид углерода"
        ws['G16'].alignment = wrap_text
        ws['G17'] = str(HARG_data.get("co_otnos_speed"))
        ws['G17'].alignment = wrap_text

        ws['A19'] = "4.Расчетные данные"

        ws['A20'] = "C2H2/C2H4"
        ws['A20'].alignment = wrap_text
        ws['A21'] = str(HARG_data.get("c2h2_c2h4"))
        ws['A21'].alignment = wrap_text

        ws['B20'] = "CH4/H2"
        ws['B20'].alignment = wrap_text
        ws['B21'] = str(HARG_data.get("ch4_h2"))
        ws['B21'].alignment = wrap_text

        ws['C20'] = "C2H4/C2H6"
        ws['C20'].alignment = wrap_text
        ws['C21'] = str(HARG_data.get("c2h4_c2h6"))
        ws['C21'].alignment = wrap_text

        ws['D20'] = "CO2/CO"
        ws['D20'].alignment = wrap_text
        ws['D21'] = str(HARG_data.get("co2_co"))
        ws['D21'].alignment = wrap_text

        ws['A23'] = "5.Заключение"

        ws['A24'] = "Дефект по 4-газам (перегрев/разряд)"
        ws['A24'].alignment = wrap_text
        ws['B24'] = str(HARG_data.get("peregrev_razryad_4_gaza"))
        ws['B24'].alignment = wrap_text

        ws['A25'] = "Дефект по 4-газам (перегрев по CO)"
        ws['A25'].alignment = wrap_text
        ws['B25'] = str(HARG_data.get("defekt_4_gaza_peregrev_CO"))
        ws['B25'].alignment = wrap_text

        ws['A26'] = "Дефект по 5-газам"
        ws['A26'].alignment = wrap_text
        ws['B26'] = str(HARG_data.get("defekt_5_gazov"))
        ws['B26'].alignment = wrap_text

        ws['A27'] = "Дефект по 5-газам (масло/твердая изоляция)"
        ws['A27'].alignment = wrap_text
        ws['B27'] = str(HARG_data.get("defekt_maslo_izolyacia_5_gazov"))
        ws['B27'].alignment = wrap_text

        ws['A29'] = "Рекомендации"
        ws['A29'].alignment = wrap_text

        ws['A36'] = "Должность"
        ws['D36'] = "Подпись"
        ws['H36'] = "ФИО"

        column_letters = (col[1].column_letter for col in ws)
        for letter in column_letters:
            ws.column_dimensions[letter].width = 17

        # Сохраняем файл

        trans_name = str(trans_info.get('name').replace('/', '-'))
        factory_n = str(trans_info.get('factory_n'))

        filename = os.getcwd() + "/reports/Отчет о состоянии трансформаторного масла "+trans_name+" №"+factory_n+" от "+ str(datetime.today().strftime('%d.%m.%Y %H-%M'))+".xlsx"

        # Сохраняем файл
        wb.save(filename)

        xl = Dispatch("Excel.Application")
        xl.Visible = True  # otherwise excel is hidden
        # xl.Workbooks.Open(os.getcwd() + "/reports/Отчет о состоянии трансформаторного масла " + str(
        #     trans_info.get('substation')) + " " + str(trans_info.get('name')) + " №" + str(
        #     trans_info.get('factory_n')) + " от " + str(datetime.today().strftime('%d.%m.%Y %H-%M')) + ".xlsx")

        self.report_output("Отчет сохранен по пути: "+filename)

        #openpyxl.load_workbook(os.getcwd()+"/reports/Отчет о состоянии трансформаторного масла от "+str(datetime.now())+".xlsx")

    def show_msg(self,text=""):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(text)
        msg.setWindowTitle("Ошибка")
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec_()

    def open_subs_win(self):
        subs_win = Substation(self)
        subs_win.show_window()

    def open_trans_win(self):
        trans_win = Transformator(self)
        trans_win.show_window()

    def report_output(self,data):
        self.result_txt.append((str)(data))

    def show_window(self):
        self.show()

    def close_window(self):
        self.close()

if __name__ == '__main__':
    app = QApplication([])
    main = Main()
    main.show()
    app.exec_()