import shutil
import os


def copy_to_usb(source_file, destination_path):
    """
    Копирует файл на USB-накопитель.

    Args:
        source_file (str): Путь к исходному файлу.
        destination_path (str): Путь на флешке, куда нужно скопировать файл.
    """
    try:
        shutil.copy2(source_file, destination_path)
        print(f"Файл '{source_file}' успешно скопирован в '{destination_path}'")
    except FileNotFoundError:
        print(f"Ошибка: Файл '{source_file}' не найден.")
    except PermissionError:
        print(f"Ошибка: Нет прав доступа для записи в '{destination_path}'.")
    except Exception as e:
        print(f"Произошла ошибка при копировании: {e}")


if __name__ == "__main__":
    # Замените на реальные пути
    source_file_path = "C:/Users/YAFayzullin/Documents/служебные письма/отработанные/КИИ/отправка во фстэк сведения по категорированию/CD/CD.7z"  # Пример: /home/user/my_file.txt
    usb_drive_path = "D:/"  # Пример: /media/user/DISK_NAME/

    r = 20000

    for i in range(r):
        # Убедитесь, что директория существует, прежде чем пытаться копировать
        if not os.path.exists(usb_drive_path):
            print(f"Ошибка: Директория '{usb_drive_path}' не существует.")
        else:
            copy_to_usb(source_file_path, usb_drive_path)

#copy_to_usb("C:/Users/YAFayzullin/Documents/служебные письма/отработанные/КИИ/отправка во фстэк сведения по категорированию/CD/CD.7z","D:/")























#СКРИПТ ДЛЯ ОБЪЕДИНЕНИЯ TIFF ФАЙЛОВ В PDF

# from PIL import Image
# import os
# # Список TIFF-файлов
#
# directory = r'C:\Users\YAFayzullin\Documents\служебные письма\отработанные\КИИ\ПОДПИСАННЫЕ АКТЫ КАТЕГОРИРОВАНИЯ\сведения\Соколовка\tif'
# r_tif_files = os.listdir(directory)  # Получаем название всего содержимого папки;
#
# tif_files = []
#
# for item in r_tif_files:
#   tif_files.append('C:/Users/YAFayzullin/Documents/служебные письма/отработанные/КИИ\ПОДПИСАННЫЕ АКТЫ КАТЕГОРИРОВАНИЯ/сведения/Соколовка/tif/'+item)
# print(tif_files)
#
# # Открываем первый файл
# images = [Image.open(tif_files[0])]
#
# # Открываем остальные файлы и добавляем их к списку
# for tif in tif_files[1:]:
#     img = Image.open(tif)
#     images.append(img)
#
# # Сохраняем как PDF
# images[0].save('output.pdf', save_all=True, append_images=images[1:])