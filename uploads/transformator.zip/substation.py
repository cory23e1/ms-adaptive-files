from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import QtCore, QtGui, QtWidgets, QtSql

import substations_form
import sys
#import main
import sqlite3
import os
import shutil

# здесь можно определить какие нибудь переменные, костянки
#connection = sqlite3.connect('transformators.db')
con = QtSql.QSqlDatabase.addDatabase('QSQLITE')
con.setDatabaseName('transformators.db')
con.open()

class Substation(substations_form.Ui_MainWindow,QMainWindow):

    def __init__(self,parent=None):

        super(Substation, self).__init__(parent)
        #self.parent = parent
        #QtWidgets.QWidget.__init__(self, parent)
        self.setWindowFlags(QtCore.Qt.Window)
        self.setWindowModality(QtCore.Qt.WindowModal)
        #super(Settings, self).__init__(parent)
        self.setupUi(self)

        # СЮДА МОЖНО НАЕБЕНИТЬ КАКИЕ НИБУДЬ ФУНКЦИИ КОТОРЫЕ БУДУТ ВЫЗЫВАТЬСЯ ПРИ СТАРТЕ
        self.load_subs()

        #БИНДЫ КЛИКОВ ТРИГГЕРОВ И.Т.Д.
        self.add_subs_btn.clicked.connect(self.add_subs)
        self.del_subs_btn.clicked.connect(self.del_subs)

    def show_window(self):
         self.show()

    def add_subs(self):
        #сбор данных с инпутов
        name = str(self.subs_name_txt.text())
        data = (name,)

        connection = sqlite3.connect('transformators.db')

        #добавление в БД
        cursor = connection.cursor()
        sql = 'INSERT INTO substations (name) VALUES (?)'
        cursor.execute(sql, data)
        connection.commit()
        print(name)

        #очистка инпутов
        self.subs_name_txt.setText("")

        #обновление БД
        self.load_subs()

    def load_subs(self):
        stm = QtSql.QSqlQueryModel(parent=self.subs_tbl)
        stm.setQuery('SELECT id AS "id", name AS "Наименование" FROM substations')
        self.subs_tbl.setModel(stm)

    def del_subs(self):

        #получение ID подстанци по выделенной строке в таблице
        row = self.subs_tbl.currentIndex().row()
        selected_subs_index = self.subs_tbl.model().index(row, 0).data()

        #удаление подстанции из БД
        connection = sqlite3.connect('transformators.db')

        #запрос на удаление
        cursor = connection.cursor()
        sql_delete_query = "DELETE from substations where id = "+str(selected_subs_index)
        cursor.execute(sql_delete_query)
        connection.commit()

        #сброс табрицы
        self.load_subs()

if __name__ == '__main__':
    app = QApplication([])
    subs = Substation()
    subs.show()
    app.exec_()