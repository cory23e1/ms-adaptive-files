import sqlite3
from datetime import datetime

class SQL:

    def __init__(self):
        self.connect = sqlite3.connect('transformators.db')

    def get_data(self,sql_query="", type="default"):
        cursor = self.connect.cursor()
        cursor.execute(sql_query)
        data = ""
        if (type=="default"):
            data = cursor.fetchall()
        elif (type=="dict"):
            columns = [description[0] for description in cursor.description]
            rows = cursor.fetchall()[0]
            data = dict(zip(columns,rows))
        return data

    def insert_data(self,sql_query="",data=()):
        cursor = self.connect.cursor()
        cursor.execute(sql_query, data)
        self.connect.commit()

    def del_data(self,sql_query=""):
        cursor = self.connect.cursor()
        cursor.execute(sql_query)
        self.connect.commit()