import sqlite3
from datetime import datetime
from SQL import SQL
from PyQt5 import QtSql
from PyQt5.QtGui import *

class HARG:

    def __init__(self,trans_id, H2="1,0",CH4="1,0",C2H4="1,0",C2H2="1,0",C2H6="1,0",CO2="1,0",CO="1,0",HARG_DATE="01.01.2000"):
        self.trans_id = str(trans_id)
        self.H2 = float(str(H2).replace(",", "."))
        self.CH4 = float(str(CH4).replace(",", "."))
        self.C2H4 = float(str(C2H4).replace(",", "."))
        self.C2H2 = float(str(C2H2).replace(",", "."))
        self.C2H6 = float(str(C2H6).replace(",", "."))
        self.CO2 = float(str(CO2).replace(",", "."))
        self.CO = float(str(CO).replace(",", "."))

        self.C2H2_C2H4 = self.C2H2/self.C2H4
        self.CH4_H2 = self.CH4/self.H2

        self.C2H4_C2H6 = self.C2H4/self.C2H6
        self.CO2_CO = self.CO2 / self.CO

        self.HARG_DATE = str(HARG_DATE)

        self.gran_conc_res = {"result":""}

        self.H2_absolut_speed = ""
        self.CH4_absolut_speed = ""
        self.C2H4_absolut_speed = ""
        self.C2H2_absolut_speed = ""
        self.C2H6_absolut_speed = ""
        self.CO2_absolut_speed = ""
        self.CO_absolut_speed = ""

        self.H2_otnos_speed = ""
        self.CH4_otnos_speed = ""
        self.C2H4_otnos_speed = ""
        self.C2H2_otnos_speed = ""
        self.C2H6_otnos_speed = ""
        self.CO2_otnos_speed = ""
        self.CO_otnos_speed = ""

        self.peregrev_razryad_4_gaza = {"result":""}
        self.result_defekt_4_gaza_peregrev_CO = {"result":""}
        self.result_defekt_5_gazov = {"result":""}
        self.result_defekt_maslo_izolyacia_5_gazov = {"result":""}

        self.sql = SQL()

    def previshenie_granich_concentraciy(self):

        max_H2 = 0.01
        max_CH4 = 0.01
        max_C2H4 = 0.01
        max_C2H2 = 0.001
        max_C2H6 = 0.005
        max_CO2_VOF_trans_exploitation_more_10_years = 0.8
        max_CO2_VOF_trans_exploitation_less_10_years = 0.6
        max_CO2_PLENKA_trans_exploitation_more_10_years = 0.4
        max_CO2_PLENKA_trans_exploitation_less_10_years = 0.2
        max_CO = 0.06

        trans_protect = "ВОФ"

        if (self.H2 >= max_H2
            or
            self.CH4 >= max_CH4
            or
            self.C2H2 >= max_C2H2
            or
            self.C2H4>= max_C2H4
            or
            self.C2H6 >= max_C2H6
            or
            self.CO2 >= (max_CO2_VOF_trans_exploitation_more_10_years if trans_protect == "ВОФ" else max_CO2_PLENKA_trans_exploitation_more_10_years) or self.CO >= (max_CO if trans_protect == "ВОФ" else 0.05)):

            self.gran_conc_res["result"] = "превышение"
            return "превышение"
        else:
            self.gran_conc_res["result"] = "норма"
            return "норма"

    def absolut_narastanie_gas_speed(self):

        prev_gas_data = self.get_prev_gas_data()
        HARG_prev_gases = prev_gas_data.get('prev_gas_data')
        raznica = prev_gas_data.get('raznica')

        #ОГРАНИЧЕНИЕ ГАЗОВ
        absolut_speeds_gas_up = {"H2":0.00005, "CH4": 0.00005, "C2H4": 0.00005, "C2H2": 0.00005, "C2H6":0.00005, "CO2":0.0015, "CO":0.00005}

        #АБСОЛЮТНАЯ СКОРОСТЬ НАРАСТАНИЯ

        def calculate_absolute_gas_speed_up(GAS_conc,GAS_name):

            ratio = (GAS_conc - HARG_prev_gases.get(GAS_name)) / raznica.days
            print(ratio)
            if absolut_speeds_gas_up.get(GAS_name)=="C2H2":
                if ratio < 0.00005:
                    result = "отсутствие дефекта"
                elif ratio < 0.00015:
                    result = "наличие дефекта"
                else:
                    result = "быстрое развитие дефекта"
            else:
                if ratio < absolut_speeds_gas_up.get(GAS_name):
                    result = "отсутствие дефекта"
                elif ratio == absolut_speeds_gas_up.get(GAS_name):
                    result = "наличие дефекта"
                else:
                    result = "быстрое развитие дефекта"

            return result

        self.H2_absolut_speed = calculate_absolute_gas_speed_up(self.H2,'H2')
        self.CH4_absolut_speed = calculate_absolute_gas_speed_up(self.CH4, 'CH4')
        self.C2H4_absolut_speed = calculate_absolute_gas_speed_up(self.C2H4, 'C2H4')
        self.C2H2_absolut_speed = calculate_absolute_gas_speed_up(self.C2H2, 'C2H2')
        self.C2H6_absolut_speed = calculate_absolute_gas_speed_up(self.C2H6, 'C2H6')
        self.CO2_absolut_speed = calculate_absolute_gas_speed_up(self.CO2, 'CO2')
        self.CO_absolut_speed = calculate_absolute_gas_speed_up(self.CO, 'CO')

        return " "+" \n"+ self.H2_absolut_speed + "\n "+self.CH4_absolut_speed + "\n "+self.C2H4_absolut_speed + "\n "+self.C2H2_absolut_speed + "\n "+self.C2H6_absolut_speed + "\n "+self.CO2_absolut_speed + "\n "+self.CO_absolut_speed

    def otnos_narastanie_gas_speed(self):

        prev_gas_data = self.get_prev_gas_data()
        HARG_prev_gases = prev_gas_data.get('prev_gas_data')
        raznica = prev_gas_data.get('raznica')

        #АБСОЛЮТНАЯ СКОРОСТЬ НАРАСТАНИЯ

        def calculate_otnos_gas_speed_up(GAS_conc,GAS_name):
            result = (GAS_conc - HARG_prev_gases.get(GAS_name)) / raznica.days / HARG_prev_gases.get(GAS_name) *30 * 100
            return str(result)

        self.H2_otnos_speed = calculate_otnos_gas_speed_up(self.H2,'H2')
        self.CH4_otnos_speed = calculate_otnos_gas_speed_up(self.CH4, 'CH4')
        self.C2H4_otnos_speed = calculate_otnos_gas_speed_up(self.C2H4, 'C2H4')
        self.C2H2_otnos_speed = calculate_otnos_gas_speed_up(self.C2H2, 'C2H2')
        self.C2H6_otnos_speed = calculate_otnos_gas_speed_up(self.C2H6, 'C2H6')
        self.CO2_otnos_speed = calculate_otnos_gas_speed_up(self.CO2, 'CO2')
        self.CO_otnos_speed = calculate_otnos_gas_speed_up(self.CO, 'CO')

        return " "+" \n"+ self.H2_otnos_speed + "\n "+self.CH4_otnos_speed + "\n "+self.C2H4_otnos_speed + "\n "+self.C2H2_otnos_speed + "\n "+self.C2H6_otnos_speed + "\n "+self.CO2_otnos_speed + "\n "+self.CO_otnos_speed

    def defekt_4_gaza_peregrev_razryad(self):

        gran_conc_res = self.gran_conc_res.get('result')

        print("C2H2/C2H4 = "+str(self.C2H2_C2H4))
        print("CH4/H2 = " + str(self.CH4_H2))

        if gran_conc_res != "превышение":
            return "норма"
        else:
            if self.C2H2_C2H4 >= 0.1 and self.CH4_H2 <= 0.5:
                self.peregrev_razryad_4_gaza["result"] = "разряд"
                return "разряд"
            elif self.C2H2_C2H4 < 0.1 and self.CH4_H2 > 0.5:
                self.peregrev_razryad_4_gaza["result"] = "перегрев"
                return "перегрев"
            elif self.C2H2_C2H4 >= 0.1 and self.CH4_H2 > 0.5:
                self.peregrev_razryad_4_gaza["result"] = "перегрев и разряд"
                return "перегрев и разряд"
            elif self.C2H2_C2H4 < 0.1 and self.CH4_H2 <= 0.5:
                self.peregrev_razryad_4_gaza["result"] = "перегрев и разряд"
                return "перегрев и разряд"
            else:
                return 0

    def defekt_4_gaza_peregrev_CO(self):

        peregrev_razryad = self.peregrev_razryad_4_gaza.get('result')
        if peregrev_razryad == "перегрев" and self.CO <= 0.05:
            self.result_defekt_4_gaza_peregrev_CO["result"] = "перегрев масла"
            return "перегрев масла"
        elif peregrev_razryad == "перегрев" and self.CO > 0.05:
            self.result_defekt_4_gaza_peregrev_CO["result"] = "перегрев твердой изоляции"
            return "перегрев твердой изоляции"
        else:
            self.result_defekt_4_gaza_peregrev_CO["result"] = "норма"
            return "норма"

    def defekt_5_gazov(self):

        if self.C2H2_C2H4 < 0.1 and 0.1 < self.CH4_H2 < 1 and self.C2H4_C2H6 <= 1:
            self.result_defekt_5_gazov["result"] = "Нормально"
            return "Нормально"
        elif self.C2H2_C2H4 < 0.1 and self.CH4_H2 < 0.1 and self.C2H4_C2H6 <= 1:
            self.result_defekt_5_gazov["result"] = "Частичные разряды с низкой плотностью энергии"
            return "Частичные разряды с низкой плотностью энергии"
        elif 0.1 < self.C2H2_C2H4 < 3 and self.CH4_H2 < 0.1 and self.C2H4_C2H6 <= 1:
            self.result_defekt_5_gazov["result"] = "Частичные разряды с высокой плотностью энергии"
            return "Частичные разряды с высокой плотностью энергии"
        elif 0.1 < self.C2H2_C2H4 < 3 and 0.1 < self.CH4_H2 < 1 and 1 < self.C2H4_C2H6 < 3:
            self.result_defekt_5_gazov["result"] = "Разряды малой мощности"
            return "Разряды малой мощности"
        elif 0.1 < self.C2H2_C2H4 < 3 and 0.1 < self.CH4_H2 < 1 and self.C2H4_C2H6 >= 3:
            self.result_defekt_5_gazov["result"] = "Разряды большой мощности"
            return "Разряды большой мощности"
        elif self.C2H2_C2H4 < 0.1 and 0.1 < self.CH4_H2 < 1 and 1 < self.C2H4_C2H6 < 3:
            self.result_defekt_5_gazov["result"] = "Термический дефект низкой температуры (< 150 °С)"
            return "Термический дефект низкой температуры (< 150 °С)"
        elif self.C2H2_C2H4 < 0.1 and self.CH4_H2 >= 1 and self.C2H4_C2H6 < 1:
            self.result_defekt_5_gazov["result"] = "Термический дефект в диапазоне низких температур (150-300 °С)"
            return "Термический дефект в диапазоне низких температур (150-300 °С)"
        elif self.C2H2_C2H4 < 0.1 and self.CH4_H2 >= 1 and 1 < self.C2H4_C2H6 < 3:
            self.result_defekt_5_gazov["result"] = "Термический дефект в диапазоне средних температур (300-700 °С)"
            return "Термический дефект в диапазоне средних температур (300-700 °С)"
        elif self.C2H2_C2H4 < 0.1 and self.CH4_H2 >= 1 and self.C2H4_C2H6 >= 3:
            self.result_defekt_5_gazov["result"] = "Термический дефект высокой температуры (> 700 °С)"
            return "Термический дефект высокой температуры (> 700 °С)"
        else:
            self.result_defekt_5_gazov["result"] = "Не прогнозируемый дефект"
            return "Не прогнозируемый дефект"

    def defekt_maslo_izolyacia_5_gazov(self):
        if self.result_defekt_5_gazov["result"] == "Нормально":
            self.result_defekt_maslo_izolyacia_5_gazov["result"] = "норма"
            return "норма"
        elif self.CO2_CO < 5:
            self.result_defekt_maslo_izolyacia_5_gazov["result"] = "повреждение изоляции t<160C"
            return "повреждение изоляции t<160C"
        elif self.CO2_CO > 13:
            self.result_defekt_maslo_izolyacia_5_gazov["result"] = "повреждение изоляции t>200C"
            return "повреждение изоляции t>200C"
        else:
            self.result_defekt_maslo_izolyacia_5_gazov["result"] = "повреждение масла"
            return "повреждение масла"

    def get_prev_gas_data(self):
        #ПОЛУЧЕНИЕ ПРЕДЫЩЕГО ОТБОРА
        con = sqlite3.connect('transformators.db')
        cursor = con.cursor()
        cursor.execute("SELECT " +
                       "otbor.date AS date " +
                       "FROM otbor " +
                       "WHERE transformator=" + self.trans_id
                       )
        raw_HARG_dates = cursor.fetchall()
        formated_HARG_date = datetime.strptime(self.HARG_DATE, "%d.%m.%Y")
        formated_HARG_dates = []

        for item in raw_HARG_dates:
            formated_HARG_dates.append(datetime.strptime(item[0], "%d.%m.%Y"))
        closest_date = min(formated_HARG_dates, key=lambda date: abs(date - formated_HARG_date))

        #РАЗНИЦА МЕЖДУ ДАТОЙ ТЕКУЩЕГО ХАРГ И ПРОШЛОГО (В ДНЯХ)
        raznica = formated_HARG_date - closest_date

        formated_closest_date = closest_date.strftime("%d.%m.%Y")

        #ПОЛУЧЕНИЕ ДАННЫХ ГАЗОВ ПО ДАТЕ И ИД ТРАНСФОРМАТОРА
        con2 = sqlite3.connect('transformators.db')
        cursor2 = con2.cursor()
        cursor2.execute("SELECT h2 AS H2, ch4 AS CH4, c2h4 AS C2H4, c2h2 AS C2H2, c2h6 AS C2H6, co2 AS CO2, co AS CO FROM otbor WHERE transformator ="+self.trans_id+" AND date ='"+formated_closest_date+"'")

        columns = [description[0] for description in cursor2.description]
        rows = cursor2.fetchall()[0]

        raw_HARG_prev_gases = []

        for gas in rows:
            raw_HARG_prev_gases.append(float(str(gas).replace(",", ".")))

        prev_gas_data = dict(zip(columns, raw_HARG_prev_gases))

        return {"prev_gas_data":prev_gas_data, "raznica":raznica}

    def do_HARG(self):
        #ПРЕВЫШЕНИЕ ГРАНИЧНЫХ КОНЦЕНТРАЦИЙ
        previshenie_granich_concentraciy = self.previshenie_granich_concentraciy()

        #АБСОЛЮТНАЯ СКОРОСТЬ НАРАСТАНИЯ
        absolut_narastanie_gas_speed = self.absolut_narastanie_gas_speed()

        #ОТНОСИТЕЛЬНАЯ СКОРОСТЬ НАРАСТАНИЯ
        otnos_narastanie_gas_speed = self.otnos_narastanie_gas_speed()

        #ДЕФЕКТ ПО 4-ГАЗАМ ПЕРЕГРЕВ РАЗРЯД
        defekt_4_gaza_peregrev_razryad = self.defekt_4_gaza_peregrev_razryad()

        # ДЕФЕКТ ПО 4-ГАЗАМ ПЕРЕГРЕВ РАЗРЯД
        defekt_4_gaza_peregrev_CO = self.defekt_4_gaza_peregrev_CO()

        # ДЕФЕКТ ПО 5-ГАЗАМ
        defekt_5_gazov = self.defekt_5_gazov()

        #ДЕФЕКТ ПО 5-ГАЗАМ ПОВРЕЖДЕНИЕ МАСЛА/ПОВРЕЖДЕНИЕ ИЗОЛЯЦИИ
        defekt_maslo_izolyacia_5_gazov = self.defekt_maslo_izolyacia_5_gazov()


        #ОБШИЙ ВЫВОД
        result = "H2="+str(self.H2)+"\n"+"CH4="+str(self.CH4)+"\n"+"C2H4="+str(self.C2H4)+"\n"+"C2H2="+str(self.C2H2)+"\n"+"C2H6="+str(self.C2H6)+"\n"+"CO2="+str(self.CO2)+"\n"+"CO="+str(self.CO)+"\n"+\
                 "ПРЕВЫШЕНИЕ ГРАНИЦ КОНЦЕНТРАЦИЙ: "+previshenie_granich_concentraciy +' \n' +\
                 "АБСОЛЮТНАЯ СКОРОСТЬ НАРАСТАНИЯ ГАЗОВ: "+str(absolut_narastanie_gas_speed)+' \n' + \
                 "ОТНОСИТЕЛЬНАЯ СКОРОСТЬ НАРАСТАНИЯ ГАЗОВ: " + str(otnos_narastanie_gas_speed) + ' \n' + \
                 "ДЕФЕКТ ПО 4-ГАЗАМ ПЕРЕГРЕВ/РАЗРЯД: " + str(defekt_4_gaza_peregrev_razryad) + ' \n' + \
                 "ДЕФЕКТ ПО 4-ГАЗАМ ПЕРЕГРЕВ ПО CO: " + str(defekt_4_gaza_peregrev_CO) + ' \n'+ \
                 "ДЕФЕКТ ПО 5-ГАЗАМ: " + str(defekt_5_gazov) + ' \n' + \
                 "ДЕФЕКТ ПО 5-ГАЗАМ ПОВРЕЖДЕНИЕ МАСЛА/ИЗОЛЯЦИИ: " + str(defekt_maslo_izolyacia_5_gazov) + ' \n'

        self.record_HARG_to_bd()
        #self.sel_last_HARG()

        return result

    def record_HARG_to_bd(self):

        transformator = self.trans_id
        HARG_date = datetime.today().strftime('%d.%m.%Y %H:%M')
        H2 = self.H2
        CH4 = self.CH4
        C2H4 = self.C2H4
        C2H2 = self.C2H2
        C2H6 = self.C2H6
        CO2 = self.CO2
        CO = self.CO

        C2H2_C2H4 = self.C2H2_C2H4
        CH4_H2 = self.CH4_H2

        C2H4_C2H6 = self.C2H4_C2H6
        CO2_CO = self.CO2_CO

        previshenie_granich_concentraciy = self.gran_conc_res.get("result")

        H2_absolut_speed = self.H2_absolut_speed
        CH4_absolut_speed = self.CH4_absolut_speed
        C2H4_absolut_speed = self.C2H4_absolut_speed
        C2H2_absolut_speed = self.C2H2_absolut_speed
        C2H6_absolut_speed = self.C2H6_absolut_speed
        CO2_absolut_speed = self.CO2_absolut_speed
        CO_absolut_speed = self.CO_absolut_speed

        H2_otnos_speed = self.H2_otnos_speed
        CH4_otnos_speed = self.CH4_otnos_speed
        C2H4_otnos_speed = self.C2H4_otnos_speed
        C2H2_otnos_speed = self.C2H2_otnos_speed
        C2H6_otnos_speed = self.C2H6_otnos_speed
        CO2_otnos_speed = self.CO2_otnos_speed
        CO_otnos_speed = self.CO_otnos_speed

        peregrev_razryad_4_gaza = self.peregrev_razryad_4_gaza.get("result")
        result_defekt_4_gaza_peregrev_CO = self.result_defekt_4_gaza_peregrev_CO.get("result")
        result_defekt_5_gazov = self.result_defekt_5_gazov.get("result")
        result_defekt_maslo_izolyacia_5_gazov = self.result_defekt_maslo_izolyacia_5_gazov.get("result")
        recomends = ""

        data = (transformator, HARG_date,
                H2, CH4, C2H4, C2H2, C2H6, CO2, CO, C2H2_C2H4, CH4_H2, C2H4_C2H6, CO2_CO,
                previshenie_granich_concentraciy,
                H2_absolut_speed, CH4_absolut_speed, C2H4_absolut_speed, C2H2_absolut_speed, C2H6_absolut_speed, CO2_absolut_speed, CO_absolut_speed,
                H2_otnos_speed, CH4_otnos_speed, C2H4_otnos_speed, C2H2_otnos_speed, C2H6_otnos_speed, CO2_otnos_speed, CO_otnos_speed,
                peregrev_razryad_4_gaza,
                result_defekt_4_gaza_peregrev_CO,
                result_defekt_5_gazov,
                result_defekt_maslo_izolyacia_5_gazov,
                recomends
                )

        self.sql.insert_data(
            "INSERT INTO HARG (transformator, date, "
            "h2, ch4, c2h4, c2h2, c2h6, co2, co, c2h2_c2h4, ch4_h2, c2h4_c2h6, co2_co, "
            "previshenie_granich_concentraciy, "
            "h2_absolut_speed, ch4_absolut_speed, c2h4_absolut_speed, c2h2_absolut_speed, c2h6_absolut_speed, co2_absolut_speed, co_absolut_speed, "
            "h2_otnos_speed, ch4_otnos_speed, c2h4_otnos_speed, c2h2_otnos_speed, c2h6_otnos_speed, co2_otnos_speed, co_otnos_speed, "
            "peregrev_razryad_4_gaza, "
            "defekt_4_gaza_peregrev_CO, "
            "defekt_5_gazov, "
            "defekt_maslo_izolyacia_5_gazov, "
            "recomends) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        ,data)

    def sel_last_HARG(self):

        con = sqlite3.connect('transformators.db')
        cursor = con.cursor()

        cursor.execute("SELECT " +
                       "date AS date," +
                       "transformators.name AS transformator," +
                       "h2 AS h2," +
                       "ch4 AS ch4," +
                       "c2h4 AS c2h4," +
                       "c2h2 AS c2h2," +
                       "c2h6 AS c2h6," +
                       "co2 AS co2," +
                       "co AS co," +
                       "c2h2_c2h4 AS c2h2_c2h4," +
                       "ch4_h2 AS ch4_h2," +
                       "c2h4_c2h6 AS c2h4_c2h6," +
                       "co2_co AS co2_co, " +
                       "previshenie_granich_concentraciy AS previshenie_granich_concentraciy, " +
                       "h2_absolut_speed AS h2_absolut_speed, " +
                       "ch4_absolut_speed AS ch4_absolut_speed, " +
                       "c2h4_absolut_speed AS c2h4_absolut_speed, " +
                       "c2h2_absolut_speed AS c2h2_absolut_speed, " +
                       "c2h6_absolut_speed AS c2h6_absolut_speed, " +
                       "co2_absolut_speed AS co2_absolut_speed, " +
                       "co_absolut_speed AS co_absolut_speed, " +
                       "h2_otnos_speed AS h2_otnos_speed, " +
                       "ch4_otnos_speed AS ch4_otnos_speed, " +
                       "c2h4_otnos_speed AS c2h4_otnos_speed, " +
                       "c2h2_otnos_speed AS c2h2_otnos_speed, " +
                       "c2h6_otnos_speed AS c2h6_otnos_speed, " +
                       "co2_otnos_speed AS co2_otnos_speed, " +
                       "co_otnos_speed AS co_otnos_speed, " +
                       "peregrev_razryad_4_gaza AS peregrev_razryad_4_gaza, " +
                       "defekt_4_gaza_peregrev_CO AS defekt_4_gaza_peregrev_CO, " +
                       "defekt_5_gazov AS defekt_5_gazov, " +
                       "defekt_maslo_izolyacia_5_gazov AS defekt_maslo_izolyacia_5_gazov, " +
                       "recomends AS recomends " +
                       "FROM HARG " +
                       "INNER JOIN transformators ON HARG.transformator=transformators.id " +
                       "WHERE transformator = ? " +  # Используйте параметризацию для безопасности
                       "ORDER BY date DESC LIMIT 1", (self.trans_id,)  # Передайте значение как кортеж
                       )

        columns = [description[0] for description in cursor.description]
        rows = cursor.fetchall()

        if rows:
            HARG_data = dict(zip(columns, rows[0]))  # Берем первый (и единственный) результат
        else:
            # Обрабатываем ситуацию, когда данных нет
            HARG_data = None  # Или возвращаем пустой словарь {}, или поднимаем исключение, или возвращаем какое-то значение по умолчанию

        con.close()  # Закрываем соединение

        return HARG_data


    def sel_all_HARG(self):

        con = sqlite3.connect('transformators.db')
        cursor = con.cursor()

        cursor.execute("SELECT " +
                       "date AS date," +
                       "previshenie_granich_concentraciy AS previshenie_granich_concentraciy, " +
                       "h2_absolut_speed AS h2_absolut_speed, " +
                       "ch4_absolut_speed AS ch4_absolut_speed, " +
                       "c2h4_absolut_speed AS c2h4_absolut_speed, " +
                       "c2h2_absolut_speed AS c2h2_absolut_speed, " +
                       "c2h6_absolut_speed AS c2h6_absolut_speed, " +
                       "co2_absolut_speed AS co2_absolut_speed, " +
                       "co_absolut_speed AS co_absolut_speed, " +
                       "h2_otnos_speed AS h2_otnos_speed, " +
                       "ch4_otnos_speed AS ch4_otnos_speed, " +
                       "c2h4_otnos_speed AS c2h4_otnos_speed, " +
                       "c2h2_otnos_speed AS c2h2_otnos_speed, " +
                       "c2h6_otnos_speed AS c2h6_otnos_speed, " +
                       "co2_otnos_speed AS co2_otnos_speed, " +
                       "co_otnos_speed AS co_otnos_speed, " +
                       "peregrev_razryad_4_gaza AS peregrev_razryad_4_gaza, " +
                       "defekt_4_gaza_peregrev_CO AS defekt_4_gaza_peregrev_CO, " +
                       "defekt_5_gazov AS defekt_5_gazov, " +
                       "defekt_maslo_izolyacia_5_gazov AS defekt_maslo_izolyacia_5_gazov " +
                       "FROM HARG " +
                       "INNER JOIN transformators ON HARG.transformator=transformators.id " +
                       "WHERE transformator = ? ", (self.trans_id,)  # Передайте значение как кортеж
                       )

        columns = [description[0] for description in cursor.description]
        rows = cursor.fetchall()

        # Создаем список словарей для каждой строки
        HARG_data_all = [dict(zip(columns, row)) for row in rows]

        con.close()

        stm = QtSql.QSqlQueryModel()
        stm.setQuery("SELECT " +
                       "date AS 'Дата ХАРГ'," +
                       "previshenie_granich_concentraciy AS 'Превышение граничных концентраций', " +
                       "h2_absolut_speed AS 'Абсолютная скорость нарастания H2', " +
                       "ch4_absolut_speed AS 'Абсолютная скорость нарастания CH4', " +
                       "c2h4_absolut_speed AS 'Абсолютная скорость нарастания C2H4', " +
                       "c2h2_absolut_speed AS 'Абсолютная скорость нарастания C2H2', " +
                       "c2h6_absolut_speed AS 'Абсолютная скорость нарастания C2H6', " +
                       "co2_absolut_speed AS 'Абсолютная скорость нарастания CO2', " +
                       "co_absolut_speed AS 'Абсолютная скорость нарастания CO', " +
                       "h2_otnos_speed AS 'Относительная скорость нарастания H2', " +
                       "ch4_otnos_speed AS 'Относительная скорость нарастания CH4', " +
                       "c2h4_otnos_speed AS 'Относительная скорость нарастания C2H4', " +
                       "c2h2_otnos_speed AS 'Относительная скорость нарастания C2H2', " +
                       "c2h6_otnos_speed AS 'Относительная скорость нарастания C2H6', " +
                       "co2_otnos_speed AS 'Относительная скорость нарастания CO2', " +
                       "co_otnos_speed AS 'Относительная скорость нарастания CO', " +
                       "peregrev_razryad_4_gaza AS 'Дефект по 4-газам', " +
                       "defekt_4_gaza_peregrev_CO AS 'Дефект по 4-газам CO', " +
                       "defekt_5_gazov AS 'Дефект по 5-газам', " +
                       "defekt_maslo_izolyacia_5_gazov AS 'Дефект по 5-газам (масло/твердая изоляция)' " +
                       "FROM HARG " +
                       "INNER JOIN transformators ON HARG.transformator=transformators.id " +
                       "WHERE transformator = "+ self.trans_id
                     )
        return stm