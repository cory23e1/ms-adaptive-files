from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5 import QtCore, QtGui, QtWidgets, QtSql

import transformators_form
import sys
#import main
import database
import sqlite3
import os
import shutil
from SQL import SQL

# здесь можно определить какие нибудь переменные, костянки
connection = sqlite3.connect('transformators.db')
con = QtSql.QSqlDatabase.addDatabase('QSQLITE')
con.setDatabaseName('transformators.db')
con.open()

class Transformator(transformators_form.Ui_MainWindow,QMainWindow):

    trans_img_path = ''

    def __init__(self,parent=None):

        super(Transformator, self).__init__(parent)
        self.parent = parent
        #QtWidgets.QWidget.__init__(self, parent)
        self.setWindowFlags(QtCore.Qt.Window)
        self.setWindowModality(QtCore.Qt.WindowModal)
        #super(Settings, self).__init__(parent)
        self.setupUi(self)

        # СЮДА МОЖНО НАЕБЕНИТЬ КАКИЕ НИБУДЬ ФУНКЦИИ КОТОРЫЕ БУДУТ ВЫЗЫВАТЬСЯ ПРИ СТАРТЕ
        self.load_trans()
        self.get_substations()
        self.load_substations()
        self.load_trans_protect()

        #БИНДЫ КЛИКОВ ТРИГГЕРОВ И.Т.Д.
        self.sel_trans_btn.clicked.connect(self.sel_trans)
        self.search_trans_btn.clicked.connect(self.search_trans)
        self.clear_search_trans_btn.clicked.connect(lambda:self.load_trans(clear=True))
        self.add_trans_btn.clicked.connect(self.add_trans)
        self.img_trans_loader.clicked.connect(self.load_trans_image)
        self.del_trans_btn.clicked.connect(self.del_trans)

        self.sql = SQL()

    def show_window(self):
         self.show()

    def load_trans_image(self):
        dialog = QFileDialog.getOpenFileName(self, 'Открыть файл', '', "Файлы изображений (*.jpg *.png *.bmp)")
        self.trans_img_path = dialog[0]
        self.img_trans_input.setText(os.path.basename(self.trans_img_path))

    def add_trans(self):

        #сбор данных с инпутов
        name = str(self.model_trans_input.text())
        factory_n = str(self.number_trans_input.text())
        substation = str(self.get_substations().data(self.get_substations().index(self.ps_trans_input.currentIndex(), 0)))
        image = str(os.getcwd()+"/imgs/"+self.img_trans_input.text())
        trans_protect = str(self.get_trans_protect().data(self.get_trans_protect().index(self.protect_trans_input.currentIndex(), 0)))
        create_date_trans = str(self.create_date_trans_input.text())
        start_date_trans = str(self.date_start_trans_input.text())

        print('name ='+name+' factory_n = '+factory_n+'image = '+image)

        #добавление в БД
        data = (name, factory_n, substation, image,trans_protect, create_date_trans, start_date_trans)
        self.sql.insert_data('INSERT INTO transformators (name, factory_n, substation, image, protect, date_create, date_start) VALUES (?,?,?,?,?,?,?)',data)

        # копировать изображение трансформатора в папку
        shutil.copy2(self.trans_img_path, os.getcwd() + '/imgs')

        #очистка инпутов
        self.model_trans_input.setText("")
        self.number_trans_input.setText("")
        self.img_trans_input.setText("")

        #обновление БД
        self.load_trans()

    def load_trans(self,clear=False):

        stm = QtSql.QSqlQueryModel(parent=self.trans_tbl)
        stm.setQuery('SELECT transformators.id AS id,'+
                     'transformators.name AS "Модель",'+
                     'transformators.factory_n AS "Зав.номер",'+
                     'substations.name AS "Подстанция",'+
                     'trans_protect.name AS "Вид защиты масла",'+
                     'transformators.date_create AS "Дата изготовления",'+
                     'transformators.date_start "Ввод в эксплуатацию" '+
                     'FROM transformators '+
                     'INNER JOIN substations ON transformators.substation=substations.id '+
                     'INNER JOIN trans_protect ON transformators.protect=trans_protect.id'
                     )
        self.trans_tbl.setModel(stm)
        self.search_trans_txt.setText("")

        if clear==False:
            cursor = connection.execute('select * from transformators')
            names = list(map(lambda x: x[0], cursor.description))           #загрузка наименований столбцов (id,name,trans)
            self.search_fld_trans_cmb.addItems(names)

    def get_substations(self):
        stm = QtSql.QSqlQueryModel()
        stm.setQuery('SELECT * FROM substations')
        return stm

    def get_trans_protect(self):
        stm = QtSql.QSqlQueryModel()
        stm.setQuery('SELECT * FROM trans_protect')
        return stm

    def load_substations(self):
        substations_data = self.get_substations()
        self.ps_trans_input.setModel(substations_data)
        self.ps_trans_input.setModelColumn(1)

    def load_trans_protect(self):
        trans_protect_data = self.get_trans_protect()
        self.protect_trans_input.setModel(trans_protect_data)
        self.protect_trans_input.setModelColumn(1)

    #ПЛОХО РАБОТАЕТ
    def search_trans(self):
        if self.search_trans_txt.text()!="":
            stm = QtSql.QSqlQueryModel(parent=self.trans_tbl)
            stm.setQuery(
                'SELECT transformators.id, transformators.name, transformators.factory_n, substations.name '+
                'FROM transformators INNER JOIN substations ON transformators.substation=substations.id '+
                'WHERE '+self.search_fld_trans_cmb.currentText()+' = "'+self.search_trans_txt.text()+'"')
            self.trans_tbl.setModel(stm)

    def sel_trans(self):
        row = self.trans_tbl.currentIndex().row()
        selected_trans_index = self.trans_tbl.model().index(row, 0).data()
        self.parent.selected_trans_id = str(selected_trans_index)
        self.parent.load_trans(str(selected_trans_index))
        self.close()

    def del_trans(self):

        #получение ID трансформатора по выделенной строке в таблице
        row = self.trans_tbl.currentIndex().row()
        selected_trans_index = self.trans_tbl.model().index(row, 0).data()

        #удаление изображения трансформатора
        #получение пути трансформатора
        trans_img_path = self.sql.get_data("SELECT image from transformators where id = "+str(selected_trans_index),type="default")[0][0]

        #удаление картинки
        os.remove(str(trans_img_path))

        #запрос на удаление
        self.sql.del_data("DELETE from transformators where id = "+str(selected_trans_index))

        #сброс табрицы
        self.load_trans()

if __name__ == '__main__':
    app = QApplication([])
    trans = Transformator()
    trans.show()
    app.exec_()