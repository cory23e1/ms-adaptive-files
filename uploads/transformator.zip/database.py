import sqlite3 as sl

from PyQt5.QtSql     import QSqlDatabase, QSqlQuery, QSqlTableModel

#con = sl.connect('../db/transformators.db')

class Database:
    # конструктор
    def __init__(self):
        self.create_conn()

    def create_conn(self):
        db_connect = QSqlDatabase.QSqlDatabase.addDatabase("QSQLITE")
        db_connect.setDatabaseName("transformators.db")
        db_connect.open()
        model = QSqlDatabase.QSqlQueryModel()
        model.setQuery("SELECT id, num, data FROM table")
        #window.tableView.setModel(model)

# def create_table():
#     with con:
#         con.execute("""
#             CREATE TABLE USERS (
#                 id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
#                 name TEXT,
#                 email TEXT,
#                 company TEXT
#             );
#         """)
#
# def insert_data(data):
#     sql = 'INSERT INTO USERS (name, email, company) values(?,?,?)'
#     with con:
#         con.executemany(sql, data)